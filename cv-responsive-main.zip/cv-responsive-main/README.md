# CV en HTML et CSS.
Il permet de personnaliser son profil de manière unique et professionnelle. 
Grâce à ces deux langages, voici un CV qui se démarque visuellement et techniquement. 

[CV en HTML et CSS - Tutoriel pour rédiger et coder votre CV](https://blog.crea-troyes.fr/3485/cv-en-html-et-css-tutoriel-pour-rediger-et-coder-votre-cv/)

![CV HTML CSS Responsive](https://blog.crea-troyes.fr/wp-content/uploads/2024/06/cv.jpg.webp)
